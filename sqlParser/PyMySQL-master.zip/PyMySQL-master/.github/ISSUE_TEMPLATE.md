This project is maintained one busy person with a frail wife and an infant daughter.
My time and energy is a very limited resource. I'm not a teacher or free tech support.
Don't ask a question here.  Don't file an issue until you believe it's a not a problem with your code.
Search for friendly volunteers who can teach you or review your code on ML or Q&A sites.

See also: https://medium.com/@methane/why-you-must-not-ask-questions-on-github-issues-51d741d83fde


If you're sure it's PyMySQL's issue, report the complete steps to reproduce, from creating database.

I don't have time to investigate your issue from an incomplete code snippet.
