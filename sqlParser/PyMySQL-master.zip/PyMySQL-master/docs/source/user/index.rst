User Guide
------------

The PyMySQL user guide explains how to install PyMySQL and how to contribute to
the library as a developer.


.. toctree::
  :maxdepth: 1

  installation
  examples
  resources
  development
