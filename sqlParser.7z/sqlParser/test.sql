UPDATE
       TAB1
   SET (
       COL1
     , COL2
     , COL3
     , COL4
       )
     = (
         
       SELECT
              COL1
            , COL2
            , COL3
            , COL4
         FROM TAB2
        WHERE COL4 != 'NOT GOOD'
          AND COL5 = 'GOOD'
       )
 WHERE COL7 = 'UMMM'