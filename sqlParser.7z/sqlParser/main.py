import SqlStruct
import util    

util = util.ParseUtil()

f = open("test.sql", 'r')

structs = []
prevClauseNo = []
currFunction_list = []
groupList = ['SELECT', 'UPDATE', 'INSERT', 'DELETE']
partList = ['FROM', 'WHERE', 'GROUP', 'ORDER', 'SET', 'VALUES']

depth = 0
clauseNo = 0
currClauseNo = 0 
group = ""
part = ""

while True:

    line = f.readline()
    tokens = util.tokenize(line)

    for item in tokens:
        
        #Check Group
        if groupList.count(item) > 0:
            group = item
            part = item

        #Check Part
        if partList.count(item) > 0:
            part = item


    if not line:
        break