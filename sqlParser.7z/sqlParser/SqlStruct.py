class SqlStruct:
    group = ""
    part = ""
    keyword = ""
    depth = -1
    no = -1
    pos = -1

    def __init__(self, group, part, keyword, depth, no, pos):
        self.group = group
        self.part = part
        self.keyword = keyword
        self.depth = depth
        self.no = no